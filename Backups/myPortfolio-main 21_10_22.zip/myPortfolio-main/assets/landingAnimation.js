var typed = new Typed('#typed', {
    stringsElement: '#typed-strings',
    typeSpeed:75,
    backSpeed:100,
    loop: true
  });